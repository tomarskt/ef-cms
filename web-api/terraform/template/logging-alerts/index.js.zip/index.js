const zlib = require('zlib');
const AWS = require('aws-sdk');

const SES = new AWS.SES({
  region: 'us-east-1',
});

exports.handler = async event => {
  if (event.awslogs && event.awslogs.data) {
    const payload = Buffer.from(event.awslogs.data, 'base64');

    const logevents = JSON.parse(zlib.unzipSync(payload).toString()).logEvents;

    for (const logevent of logevents) {
      const [time, id, level, message] = logevent.message.split('\t');
      console.log(message);
      const [path, requestId, requestTime, value] = message.split('|');
      console.log(path, requestId, requestTime, value, id, time);
      if (level.toLowerCase() !== 'error') continue;
      await SES.sendEmail({
        Destination: {
          ToAddresses: ['cseibert@flexion.us'],
        },
        Message: {
          Body: {
            Text: {
              Charset: 'UTF-8',
              Data: `${requestId} ${path} ${requestTime} ${value}`,
            },
          },
          Subject: {
            Charset: 'UTF-8',
            Data: `ERROR on ${process.env.STAGE}`,
          },
        },
        Source: process.env.EMAIL_SOURCE,
      }).promise();
    }
  }
};
